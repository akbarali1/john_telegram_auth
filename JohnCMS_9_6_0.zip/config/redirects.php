<?php

// from => to
// Example:
// '/old/path/?test=1' => '/new/path/'
return [
    // '' => '',
];
