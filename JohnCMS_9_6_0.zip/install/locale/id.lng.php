<?php return array (
  'domain' => 'install',
  'plural-forms' => 'nplurals=1; plural=0;',
  'messages' => 
  array (
  ),
);