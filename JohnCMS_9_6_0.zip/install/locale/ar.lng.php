<?php return array (
  'domain' => 'install',
  'plural-forms' => 'nplurals=6; plural=(n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5);',
  'messages' => 
  array (
    '' => 
    array (
      'Preparing for installation' => 'يتم الآن البدء في التثبيت...',
      'Checking parameters' => 'مسح المعلمات',
      'Database' => 'قواعد البيانات',
      'Setting' => 'المشهدد',
    ),
  ),
);