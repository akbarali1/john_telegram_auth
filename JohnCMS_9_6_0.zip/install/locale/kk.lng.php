<?php return array (
  'domain' => 'install',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Database' => 'Дерекқор',
      'Setting' => 'Баптаулар',
      'Completion' => 'Аяқтау',
      'Yes' => 'Иә',
      'No' => 'Жоқ',
      'Continue' => 'Жалғастыру',
      'Port' => 'Порт',
    ),
  ),
);