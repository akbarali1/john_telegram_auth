<?php return array (
  'domain' => 'install',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Preparing for installation' => 'ინსტალაციისთვის მომზადება',
      'Database' => 'მონაცემთა ბაზა',
      'Setting' => 'პარამეტრები',
      'PHP version' => 'PHP ვერსია',
      'Yes' => 'დიახ',
      'No' => 'არა',
      'PHP extension PDO must be installed' => 'PHP გაფართოება PDO უნდა იყოს დაინსტალებული',
    ),
  ),
);