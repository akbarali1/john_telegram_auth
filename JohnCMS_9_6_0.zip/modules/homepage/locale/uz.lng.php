<?php return array (
  'domain' => 'homepage',
  'plural-forms' => 'nplurals=2; plural=(n > 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Free, Open Source content management system' => 'Erkin, Ochiq Manba kontentni boshqarish tizimi',
      'Download' => 'Yuklab olish',
      'Documentation' => 'Hujjatlar',
      'News' => 'Yangiliklar',
      'Features' => 'Xususiyatlar',
      'Responsive Layout' => 'O\'zgaruvchanlik',
      'Your site will appear equally well on both computers and mobile devices.' => 'Kompyuter va mobilga moslashgan',
      'Template System' => 'Andoza Tizimi',
      'Using templates, you can completely change the style of your site so that it becomes unique and not like the others.' => 'Shablonlar yordamida, noyob va boshqalar kabi emas bo\'ladi, shunday qilib saytni, butunlay sizning uslubda o\'zgartirish mumkin.',
      'High Performance' => 'Yuqori Ishlash',
      'When developing JohnCMS we pay special attention to system performance.<br>Your website will not require a powerful server for as long as possible.' => 'JohnCMS-ni ishlab chiqishda biz tizimning ishlashiga alohida e\'tibor beramiz. <br> Veb-saytingiz iloji boricha uzoq vaqt davomida kuchli serverni talab qilmaydi.',
      'Multilingual' => 'Bir necha tillarda',
      'Reach the maximum audience in different languages. Several languages have already been built into the system.<br>And if you don\'t have the desired language, you can easily add it using advanced translation tools that support johnCMS.' => 'Turli tillarda maksimal auditoriyaga erishing. Tizimga allaqachon bir nechta tillar kiritilgan. Agar siz istagan tilga ega bo\'lmasangiz, uni johnCMS-ni qo\'llab-quvvatlaydigan ilg\'or tarjima vositalari yordamida qo\'shishingiz mumkin.',
      'Modularity' => 'Modulli',
      'The most popular modules are built into the system.<br>You can install ready-made additional modules, create them yourself or order development of new modules from other developers.' => 'Tizimda eng ommabop modullar o\'rnatilgan. <br> Siz qo\'shimcha qo\'shimcha modullarni o\'rnatib, ularni o\'zingiz yaratishingiz yoki boshqa ishlab chiquvchilar tomonidan yangi modullarni ishlab chiqarishga buyurtma berishingiz mumkin.',
      'Free License' => 'Bepul Litsenziya',
      'The GNU GPL-3 license gives you the right to distribute and modify JohnCMS.' => 'GNU GPL-3 litsenziyasi sizga JohnCMS-ni tarqatish va o\'zgartirish huquqini beradi.',
    ),
  ),
);