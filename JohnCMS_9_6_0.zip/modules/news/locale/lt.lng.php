<?php return array (
  'domain' => 'news',
  'plural-forms' => 'nplurals=4; plural=(n%10==1 && (n%100>19 || n%100<11) ? 0 : (n%10>=2 && n%10<=9) && (n%100>19 || n%100<11) ? 1 : n%1!=0 ? 2: 3);',
  'messages' => 
  array (
    '' => 
    array (
      'News' => 'Naujienos',
      'Text' => 'Tekstas',
      'Save' => 'Išsaugoti',
      'Do you really want to delete?' => 'Ar tikrai norite ištrinti?',
      'Delete' => 'Ištrinti',
      'Cancel' => 'Atšaukti',
      'Edit' => 'Redaguoti',
      'Title' => 'Pavadinimas',
    ),
  ),
);