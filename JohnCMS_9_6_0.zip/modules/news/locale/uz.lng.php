<?php return array (
  'domain' => 'news',
  'plural-forms' => 'nplurals=2; plural=(n > 1);',
  'messages' => 
  array (
    '' => 
    array (
      'News' => 'Yangiliklar',
      'Text' => 'Matn',
      'Save' => 'Saqlash',
      'Do you really want to delete?' => 'Chindan ham o‘chirmoqchimisiz?',
      'Delete' => 'O\'chirish',
      'Cancel' => 'Bekor qilish',
      'Edit' => 'Tahrir',
      'Title' => 'Sarlavha',
    ),
  ),
);