<?php return array (
  'domain' => 'news',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'News' => 'Xəbərlər',
      'Text' => 'Mətn',
      'Save' => 'Saxla',
      'Do you really want to delete?' => 'Həqiqətən silmək istəyirsiniz?',
      'Delete' => 'Sil',
      'Cancel' => 'Ləğv Et',
      'Edit' => 'Düzəliş edin',
      'Title' => 'Başlıq',
    ),
  ),
);