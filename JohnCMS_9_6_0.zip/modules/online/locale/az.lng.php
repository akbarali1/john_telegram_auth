<?php return array (
  'domain' => 'online',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Users' => 'İstifadəçilər',
      'History' => 'Tarix',
      'Guests' => 'Qonaqlar',
      'IP Activity' => 'Top fəaliyyət',
      'Guest' => 'Qonaq',
      'Who is online?' => 'online kim var?',
      'Online' => 'Onlayn',
      'For registered users only' => 'Ancaq qeydiyyatdan keçənlər üçün',
      'List is empty' => 'Siyahı boşdur',
      'Total' => 'Ümumi',
    ),
  ),
);