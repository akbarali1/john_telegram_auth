<?php return array (
  'domain' => 'online',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Users' => 'Колдонуучулар',
      'History' => 'Тарыхы',
      'Guests' => 'Коноктор',
      'IP Activity' => 'IP аракеттер',
      'Guest' => 'Коноктор',
      'Who is online?' => 'Ким желеде?',
      'Online' => 'Онлайн',
      'For registered users only' => 'Сайтта катталган колдонуучулар үчүн',
      'List is empty' => 'Тизмеси бош',
      'Total' => 'Баары',
    ),
  ),
);