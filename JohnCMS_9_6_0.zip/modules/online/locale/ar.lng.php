<?php return array (
  'domain' => 'online',
  'plural-forms' => 'nplurals=6; plural=(n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5);',
  'messages' => 
  array (
    '' => 
    array (
      'Users' => 'الاعضاء',
      'History' => 'السّجل',
      'Guests' => 'الزوار',
      'IP Activity' => 'نشاط IP',
      'Guest' => 'ضيف',
      'Who is online?' => 'المتواجدون الآن؟',
      'Online' => 'متصل',
      'For registered users only' => 'للمستخدمين المسجلين فقط',
      'List is empty' => 'القائمة فارغة',
      'Total' => 'مجموع',
    ),
  ),
);