<?php return array (
  'domain' => 'online',
  'plural-forms' => 'nplurals=1; plural=0;',
  'messages' => 
  array (
    '' => 
    array (
      'Users' => 'Pengguna',
      'History' => 'Riwayat',
      'Guests' => 'Pengunjung',
      'IP Activity' => 'Aktivitas IP',
      'Guest' => 'Pengunjung',
      'Who is online?' => 'Siapa yang Aktif?',
      'Online' => 'Aktif',
      'For registered users only' => 'Hanya untuk pengguna',
      'List is empty' => 'Daftar kosong',
      'Total' => 'Total',
    ),
  ),
);