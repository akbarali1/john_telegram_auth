<?php return array (
  'domain' => 'online',
  'plural-forms' => 'nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);',
  'messages' => 
  array (
    '' => 
    array (
      'Users' => 'Użytkownicy',
      'History' => 'Historia',
      'Guests' => 'Goście',
      'IP Activity' => 'Aktywność IP',
      'Guest' => 'Gość',
      'Who is online?' => 'Kto jest online?',
      'Online' => 'Online',
      'For registered users only' => 'Tylko dla zarejestrowanych',
      'List is empty' => 'Lista jest pusta',
      'Total' => 'Wszystkich',
    ),
  ),
);