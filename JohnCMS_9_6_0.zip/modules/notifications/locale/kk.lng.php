<?php return array (
  'domain' => 'notifications',
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      'Notifications are cleared!' => 'Хабарландырулар жойылды!',
      'Users on registration' => 'Пайдаланушыларды тіркеу',
      'Articles on moderation' => 'Модерация туралы мақалалар',
      'Downloads on moderation' => 'Модерацияны жүктеу',
      'Ban' => 'Тыйым салу',
      'New forum posts' => 'Форумдаға ең жаңа хаттар',
      'Mail' => 'Пошта',
      'Guestbook' => 'Қонақ кітәпшасы',
      'Comments' => 'Пікірлер',
      'Settings' => 'Баптаулар',
      'Settings saved!' => 'Баптаулар сақталады!',
      'Notifications' => 'Хабарландырулар',
      'All notifications have already been read' => 'Барлық хабарландырулар оқылған.',
      'Total' => 'Барлығы',
      'Clear notifications' => 'Барлық ескертулерді тазалау.',
      'Display the number of unread messages in the forum' => 'Форумның оқылмаған жазбаларының санын көрсету',
      'Save' => 'Сақтау',
      'Cancel' => 'Бас тарту',
    ),
  ),
);