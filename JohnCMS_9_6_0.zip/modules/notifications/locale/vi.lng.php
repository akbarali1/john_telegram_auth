<?php return array (
  'domain' => 'notifications',
  'plural-forms' => 'nplurals=1; plural=0;',
  'messages' => 
  array (
    '' => 
    array (
      'Notifications are cleared!' => 'Thông báo đã được xóa!',
      'Users on registration' => 'Người dùng đăng ký',
      'Articles on moderation' => 'Bài viết cần kiểm duyệt',
      'Downloads on moderation' => 'Tệp tin cần kiểm duyệt',
      'Ban' => 'Cấm',
      'New forum posts' => 'Bài đăng mới',
      'Mail' => 'Thư',
      'Guestbook' => 'Phòng trò truyện',
      'Comments' => 'Bình luận',
      'Settings' => 'Cài đặt',
      'Settings saved!' => 'Cài đặt đã được lưu!',
      'Notifications' => 'Thông báo',
      'All notifications have already been read' => 'Tất cả các thông báo đã được đọc',
      'Total' => 'Tổng cộng',
      'Clear notifications' => 'Xóa thông báo',
      'Display the number of unread messages in the forum' => 'Hiển thị số tin chưa đọc trong diễn đàn',
      'Save' => 'Lưu',
      'Cancel' => 'Huỷ',
    ),
  ),
);